import sqlite3
import hashlib
from sqlite3 import Connection
def sha256_hash(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()
def init_database(db_name: str = 'users.db') -> Connection:
    conn = sqlite3.connect(db_name)
    with conn:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS users (
                username TEXT PRIMARY KEY,
                password_hash TEXT NOT NULL,
                full_name TEXT NOT NULL
            )
        ''')
    return conn
def register_user(conn: Connection, username: str, password: str, full_name: str) -> None:
    try:
        with conn:
            conn.execute('''
                INSERT INTO users (username, password_hash, full_name)
                VALUES (?, ?, ?)
            ''', (username, sha256_hash(password), full_name))
        print(f"Користувача '{username}' успішно зареєстровано.")
    except sqlite3.IntegrityError:
        print("Помилка: користувач із таким логіном уже існує.")
def change_user_password(conn: Connection, username: str, new_password: str) -> None:
    with conn:
        result = conn.execute('''
            UPDATE users SET password_hash = ? WHERE username = ?
        ''', (sha256_hash(new_password), username))
    if result.rowcount:
        print("Пароль успішно оновлено.")
    else:
        print("Користувача не знайдено.")
def check_login(conn: Connection, username: str, password: str) -> None:
    cur = conn.execute('SELECT password_hash FROM users WHERE username = ?', (username,))
    row = cur.fetchone()
    if row:
        if row[0] == sha256_hash(password):
            print("Авторизація успішна.")
        else:
            print("Невірний пароль.")
    else:
        print("Користувача не знайдено.")
def print_menu() -> None:
    print("\n=== Головне меню ===")
    print("1. Зареєструвати нового користувача")
    print("2. Змінити пароль")
    print("3. Перевірити логін та пароль")
    print("4. Вийти")
def menu() -> None:
    conn = init_database()
    while True:
        print_menu()
        selection = input("Виберіть опцію (1–4): ").strip()
        match selection:
            case '1':
                username = input("Логін: ").strip()
                password = input("Пароль: ").strip()
                full_name = input("Повне ім'я: ").strip()
                register_user(conn, username, password, full_name)
            case '2':
                username = input("Логін: ").strip()
                new_password = input("Новий пароль: ").strip()
                change_user_password(conn, username, new_password)
            case '3':
                username = input("Логін: ").strip()
                password = input("Пароль: ").strip()
                check_login(conn, username, password)
            case '4':
                print("Завершення роботи.")
                break
            case _:
                print("Неправильний вибір. Спробуйте ще раз.")
    conn.close()
if __name__ == "__main__":
    menu()